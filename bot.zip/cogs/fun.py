import discord
from discord.ext import commands
import random
from utils.database import update_balance

class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="ежедневный")
    @commands.cooldown(1, 86400, commands.BucketType.user)
    async def daily(self, ctx):
        reward = random.randint(100, 500)
        await update_balance(ctx.author.id, reward, self.bot.db)
        await ctx.send(f"🎁 {ctx.author.mention}, вы получили {reward} кредитов!")

    @commands.command(name="рулетка")
    @commands.cooldown(1, 30, commands.BucketType.user)
    async def roulette(self, ctx, bet: int):
        if bet <= 0:
            await ctx.send("❌ Ставка должна быть положительной!")
            return

        from utils.database import get_balance
        balance = await get_balance(ctx.author.id, self.bot.db)
        if balance < bet:
            await ctx.send("❌ Недостаточно кредитов!")
            return

        outcome = random.choice(["win", "lose", "refund"])

        if outcome == "win":
            await update_balance(ctx.author.id, bet, self.bot.db)
            await ctx.send(f"🎉 {ctx.author.mention} выиграл {bet} кредитов!")
        elif outcome == "lose":
            await update_balance(ctx.author.id, -bet, self.bot.db)
            await ctx.send(f"💀 {ctx.author.mention} проиграл {bet} кредитов...")
        else:
            await ctx.send(f"🔄 {ctx.author.mention} вернул свои {bet} кредитов.")

async def setup(bot):
    await bot.add_cog(Fun(bot))