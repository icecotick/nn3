import discord
from discord.ext import commands
from utils.database import create_tables

class Events(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        await create_tables(self.bot.db)
        print("✅ Таблицы в БД готовы!")

    @commands.Cog.listener()
    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            seconds = int(error.retry_after)
            minutes = seconds // 60
            seconds = seconds % 60
            await ctx.send(f"⏳ Подождите {minutes}м {seconds}с, прежде чем использовать эту команду снова.")
        else:
            print(f"⚠ Ошибка команды: {error}")
            await ctx.send("❌ Произошла ошибка при выполнении команды")

async def setup(bot):
    await bot.add_cog(Events(bot))