import asyncpg
from config import DATABASE_URL

async def create_db_pool():
    return await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=5)

async def create_tables(pool):
    async with pool.acquire() as conn:
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id BIGINT PRIMARY KEY,
                balance INTEGER DEFAULT 0,
                profile_description TEXT
            )
        """)
        
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS custom_roles (
                user_id BIGINT PRIMARY KEY,
                role_id BIGINT,
                role_name TEXT,
                role_color TEXT
            )
        """)
        
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS clans (
                name TEXT PRIMARY KEY,
                owner_id BIGINT,
                balance INTEGER DEFAULT 0
            )
        """)
        
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS user_clans (
                user_id BIGINT PRIMARY KEY,
                clan_name TEXT REFERENCES clans(name) ON DELETE CASCADE
            )
        """)

async def get_balance(user_id: int, pool):
    async with pool.acquire() as conn:
        result = await conn.fetchrow("SELECT balance FROM users WHERE user_id = $1", user_id)
        return result["balance"] if result else 0

async def update_balance(user_id: int, amount: int, pool):
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO users (user_id, balance) VALUES ($1, $2)
            ON CONFLICT (user_id) DO UPDATE SET balance = users.balance + $2
        """, user_id, amount)

async def get_custom_role(user_id: int, pool):
    async with pool.acquire() as conn:
        return await conn.fetchrow("SELECT * FROM custom_roles WHERE user_id = $1", user_id)

async def create_custom_role(user_id: int, role_id: int, role_name: str, role_color: str, pool):
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO custom_roles (user_id, role_id, role_name, role_color)
            VALUES ($1, $2, $3, $4)
            ON CONFLICT (user_id) DO UPDATE SET
            role_id = $2, role_name = $3, role_color = $4
        """, user_id, role_id, role_name, role_color)

async def get_user_clan(user_id: int, pool):
    async with pool.acquire() as conn:
        return await conn.fetchval("SELECT clan_name FROM user_clans WHERE user_id = $1", user_id)

async def add_user_to_clan(user_id: int, clan_name: str, pool):
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO user_clans (user_id, clan_name) VALUES ($1, $2)
            ON CONFLICT (user_id) DO UPDATE SET clan_name = $2
        """, user_id, clan_name)

async def get_profile_description(user_id: int, pool):
    async with pool.acquire() as conn:
        result = await conn.fetchrow("SELECT profile_description FROM users WHERE user_id = $1", user_id)
        return result["profile_description"] if result and result["profile_description"] else "Описание отсутствует"

async def update_profile_description(user_id: int, description: str, pool):
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO users (user_id, profile_description) VALUES ($1, $2)
            ON CONFLICT (user_id) DO UPDATE SET profile_description = $2
        """, user_id, description)