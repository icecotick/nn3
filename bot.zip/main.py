import discord
from discord.ext import commands
from config import TOKEN
from utils.database import create_db_pool
import asyncio

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

async def load_extensions():
    await bot.load_extension("cogs.economy")
    await bot.load_extension("cogs.clans")
    await bot.load_extension("cogs.profile")
    await bot.load_extension("cogs.mod")
    await bot.load_extension("cogs.fun")
    await bot.load_extension("cogs.events")

@bot.event
async def on_ready():
    bot.db = await create_db_pool()
    print(f"✅ Бот {bot.user} запущен!")

async def main():
    async with bot:
        await load_extensions()
        await bot.start(TOKEN)

if __name__ == "__main__":
    asyncio.run(main())